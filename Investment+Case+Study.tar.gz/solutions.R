# Including Libraries
library("dplyr")
library("tidyr")

#setwd("<location of data set>")

# CHECKPOINT 1 
############################################################################
# Load the companies and rounds data into two data frames and name them companies and rounds2 respectively:
companies <-  read.delim("companies.txt", sep = '\t', stringsAsFactors = FALSE)
# data in companies.txt is tab separated i.e using sep = '\t'

rounds2 <- read.csv("rounds2.csv", stringsAsFactors = FALSE, encoding = "UTF8")
# some encoding issue was there in Ubuntu i.e. using encoding = "UTF8"(manipulating data)
# or can use command -> rounds2$company_permalink <- iconv(enc2utf8(rounds2$company_permalink), sub = "byte")

#Table 1.1: Understand the Data Set 
# 1. How many unique companies are present in rounds2? 66368
length(unique(tolower(rounds2$company_permalink)))
# we can use 'company_permalink' which is also he primary key in "companies" df. Above command shows that there are 66368 unique companies in 'rounds2' df
# Used tolower() as if the some user may put in upper or lower case which should be considered as one.

# 2. How many unique companies are present in companies? 66368
length(unique(companies$permalink))
#In Company Details, it is already mentioned that 'permalink' is the unique Id of company

# 3. In the companies data frame, which column can be used as the unique key for each company? Write the name of the column.
length(unique(companies$permalink))
# 'permalink' have 66368 unique values similar to nrow(companies). Hence, 'permalink' is the column which can be used for unique key for each company

# 4. Are there any companies in the rounds2 file which are not present in companies?
# No
# The TRUE value of command "length(unique(tolower(rounds2$company_permalink))) == length(unique(companies$permalink))" indicates that both the table have equal number of distict companies

# 5. Merge the two data frames so that all variables (columns) in the companies frame are added to the rounds2 data frame. Name the merged frame master_frame.
# lowering the case for both the columns on which merging will be done.
companies$permalink <- tolower(companies$permalink)
rounds2$company_permalink <- tolower(rounds2$company_permalink)
# Merge will be done on full outer join, hence all = TRUE
master_frame <- merge(x= companies, y = rounds2, by.x ="permalink", by.y="company_permalink",all =TRUE)
# How many observations are present in master_frame? 114949
nrow(master_frame)
# 114949

# CHECKPOINT 2
############################################################################
# Cleaning Data in master_frame
# number of NA values in 'raised_amount_usd' in master_frame are 19990
sum(is.na(master_frame$raised_amount_usd))
# which can be converted to 0 as relatively small in comaprison to whole data. Therefore,
master_frame$raised_amount_usd[is.na(master_frame$raised_amount_usd)] <- 0

# Table 2.1: Average Values of Investments for Each of these Funding Types 
aggregate(master_frame$raised_amount_usd,list(master_frame$funding_round_type),mean )

# Using above query we can easily answer the following questions
# Average funding amount of venture type : 10634054.4
# Average funding amount of angel type : 764564.3
# Average funding amount of seed type : 556606.7
# Average funding amount of private equity type : 62111788.2
# Considering that Spark Funds wants to invest between 5 to 15 million USD per investment round, which investment type is the most suitable for it? : Venture
# Venture. Between $5-15 million, there are only 2 types of funding_round_type - 1.Venture(10634054.4) 2.undisclosed(6216342.6)

# CHECKPOINT 3
############################################################################

# Table 3.1: Analysing the Top 3 English-Speaking Countries
# We can do it in multiple ways
# We need to Identifying top 9 countries based on Investment type. For this, first, we can create a data frame top9 based on funding_round_type == 'venture'
top9 <- master_frame[master_frame$funding_round_type == 'venture',]
# We can create a new datframe country_funding using top9 according to total funding for each country country
country_funding <- aggregate(top9$raised_amount_usd, by = list(top9$country_code), FUN = 'sum')

# We can filter out top 10 countries (based on total investments) from country_funding and store it in top9_countries 
top9_countries <- head(arrange(country_funding,desc(country_funding[[2]])),n=10)

# Removing records for empty values and fetching country list
top9_countries <- top9_countries[!(is.na(top9_countries[[1]]) | top9_countries[[1]]==""), 1]

# Apply this top9_countries filter in top9
top9 <- master_frame[master_frame$country_code %in% top9_countries, ]

# Using below aggregate command on top9 can be used to answer all the questions
aggregate(top9$raised_amount_usd,list(top9$country_code),sum)
# 1. Top English-speaking country : USA (United States)
# 2. Second English-speaking country : GBR (United Kingdom) 
# Although companies in china raised more fund than GBR but China is not the country where English is the official language
# 3. Third English-speaking country : IND (India)

# Deleting temporary dataframes created
remove(country_funding)
remove(top9_countries)

# CHECKPOINT 4
############################################################################
# Getting the mapping file
mapping <- read.csv("mapping.csv",stringsAsFactors = FALSE)
# For mapping.csv, we should first clean and manipulate the data. mapping.csv is in wide format.
# we should first convert it in long format and in usable format
# Removing blank records and 'Blanks' column
mapping <- mapping[mapping$Blanks == 0,]
mapping[3] <- NULL

# Wide to long format
mapping <- gather(mapping, category, my_val, Automotive...Sports: Social..Finance..Analytics..Advertising)

# Removing Symmetric rows
mapping <- mapping[!(mapping$my_val == 0),]

# Removing 'my_val' column and row names
mapping <- mapping[,-3]
rownames(mapping) <- NULL

# 1. Extract the primary sector of each category list from the category_list column
master_frame <- separate(master_frame, category_list, "primary_category", sep = "\\|", extra ="drop", remove=FALSE)
# "primary_category" is the primary sector of each category list

# 2. Use the mapping file 'mapping.csv' to map each primary sector to one of the eight main sectors
master_frame <- merge(x= master_frame, y = mapping, by.x ="primary_category", by.y="category_list",all.x =TRUE)
# 'cateogy' in master_frame depicts the 8 main categories


# CHECKPOINT 5
############################################################################
# Create three separate data frames D1, D2 and D3 for each of the three countries containing the observations of funding type FT falling within the 5-15 million USD range.
D1 <-  filter(master_frame,country_code == 'USA',funding_round_type == 'venture',raised_amount_usd >= 5000000,master_frame$raised_amount_usd <= 15000000)
D2 <-  filter(master_frame,country_code == 'GBR',funding_round_type == 'venture',raised_amount_usd >= 5000000,master_frame$raised_amount_usd <= 15000000)
D3 <-  filter(master_frame,country_code == 'IND',funding_round_type == 'venture',raised_amount_usd >= 5000000,master_frame$raised_amount_usd <= 15000000)

# a. All the columns of the master_frame along with the primary sector and the main sector
# primary sector is present as 'primary_category' & the main sector is present as 'category'

# b. The total number (or count) of investments for each main sector in a separate column
D1 <- D1 %>% group_by(category) %>% mutate(cnt_inv_sec = n())
D2 <- D2 %>% group_by(category) %>% mutate(cnt_inv_sec = n())
D3 <- D3 %>% group_by(category) %>% mutate(cnt_inv_sec = n())

# c. The total amount invested in each main sector in a separate column
D1 <- D1 %>% group_by(category) %>% mutate( sum_inv_sec = sum(raised_amount_usd))
D2 <- D2 %>% group_by(category) %>% mutate( sum_inv_sec = sum(raised_amount_usd))
D3 <- D3 %>% group_by(category) %>% mutate( sum_inv_sec = sum(raised_amount_usd))

# 1. Total number of investments (count)
# USA : 12150
nrow(D1)
# GBR : 628
nrow(D2)
# IND : 330
nrow(D3)

# 2. Total amount of investment (USD)
# USA : 108531347515
sum(D1$raised_amount_usd)
# GBR : 5436843539
sum(D2$raised_amount_usd)
# IND : 2976543602
sum(D3$raised_amount_usd)

# Below commands can be used for next 6 questions
D1 %>% group_by(category) %>% summarise(count_of_records = n())
D2 %>% group_by(category) %>% summarise(count_of_records = n())
D3 %>% group_by(category) %>% summarise(count_of_records = n())

# 3.Top sector (based on count of investments)
# USA : Others
# GBR : Others
# IND : Others

# 4. Second-best sector (based on count of investments)
# USA : Cleantech...Semiconductors
# GBR : Cleantech...Semiconductors
# IND : News..Search.and.Messaging

# 5. Third-best sector (based on count of investments)
# USA : Social..Finance..Analytics..Advertising
# GBR : Social..Finance..Analytics..Advertising
# IND : Entertainment

# 6 Number of investments in the top sector
# USA (Others) : 2923
# GBR (Others) : 143
# IND (Others) : 109

# 7. Number of investments in the second-best sector
# USA (Cleantech...Semiconductors) : 2297
# GBR (Cleantech...Semiconductors) : 127
# IND (News..Search.and.Messaging) : 52


# 8. Number of investments in the third-best sector
# USA (Social..Finance..Analytics..Advertising) : 1912
# GBR (Social..Finance..Analytics..Advertising) : 98
# IND (Entertainment) : 33


# 9. For the top sector count-wise (point 3), which company received the highest investment?
# USA : Virtustream
filter(D1, category == 'Others') %>% group_by(name) %>% summarise(S = sum(raised_amount_usd)) %>% ungroup() %>% arrange(desc(S)) %>% head(1)
# GBR : Electric Cloud
filter(D2, category == 'Others') %>% group_by(name) %>% summarise(S = sum(raised_amount_usd)) %>% ungroup() %>% arrange(desc(S)) %>% head(1)
# IND : FirstCry.com
filter(D3, category == 'Others') %>% group_by(name) %>% summarise(S = sum(raised_amount_usd)) %>% ungroup() %>% arrange(desc(S)) %>% head(1)

# 9. For the top sector count-wise (point 3), which company received the highest investment?
# USA : Biodesix
filter(D1, category == 'Cleantech...Semiconductors') %>% group_by(name) %>% summarise(S = sum(raised_amount_usd)) %>% ungroup() %>% arrange(desc(S)) %>% head(1)
# GBR : EUSA Pharma
filter(D2, category == 'Cleantech...Semiconductors') %>% group_by(name) %>% summarise(S = sum(raised_amount_usd)) %>% ungroup() %>% arrange(desc(S)) %>% head(1)
# IND : GupShup
filter(D3, category == 'News..Search.and.Messaging') %>% group_by(name) %>% summarise(S = sum(raised_amount_usd)) %>% ungroup() %>% arrange(desc(S)) %>% head(1)

